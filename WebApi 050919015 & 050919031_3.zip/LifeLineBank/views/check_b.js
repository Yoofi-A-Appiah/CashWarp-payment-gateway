document.getElementById("check_balance").click();
