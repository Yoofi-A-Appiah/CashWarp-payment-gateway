<?php
session_start();
if(isset($_SESSION['amount'])){
    //unset($_SESSION['amount']);
echo "UnSET";
var_dump($_SESSION);

}
else{
    echo "not done";
    var_dump($_SESSION);
}

?>