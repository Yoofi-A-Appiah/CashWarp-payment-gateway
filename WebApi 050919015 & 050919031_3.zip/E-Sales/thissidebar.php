<div class="row row-offcanvas row-offcanvas-right">
<div class="col-xs-6 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">
	<div class="well sidebar-nav">
		<ul class="nav">
			<li><a href="thishistory.php">History</a></li>
			<li><a href="schoolmission.php">Mission, Vision, and Goal</a></li>
			<li><a href="thisorg_chart.php">Organizational Chart</a></li>
			<li>
				<hr>
			</li>
			<li><img src="img/chmsc_front.png" /></li>
		</ul>
	</div>
	<!--/.well --> 
</div>
<!--/span-->