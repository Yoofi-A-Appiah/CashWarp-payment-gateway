<?php


class Interaction{
    private $con;
    private $table = "users";
    private $table1 = "products";
    private $table2 = "sales";
    //setting attributes
    public $email;
    public $password;
    public $amount;
    public $product_name;
    public $product_price;
    public $quantity;
    public $product_id;
    public $session_id;
    public $is_available;
    public $sales_id;

    

    public function __construct($db){
        $this->con=$db;
    }

    function check_login($id){

        if (isset($_SESSION['user_id'])){
        
            $id = $_SESSION['user_id'];
            $query = "SELECT COUNT(*) from users where session_id= :session_id limit 1";
            $stmt = $this->con->prepare($query);
            $stmt->bindParam(':session_id', $this->session_id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if($row){
                $user_data = $row;
                return $user_data;
            }else{
                return null;
            }
        
        }
        else{
        //redirect to login
        header("Location: index.html");
        die;}
        }
        public function items(){
            $query = "SELECT * FROM products";

            $statement = $this->con->prepare($query);

            if($statement->execute())
            {
                $result = $statement->fetchAll();
	            $output = '';
	            foreach($result as $row)
	        {
		        $output .= '
		    <div class="col-md-3" style="margin-top:12px;">  
            <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:2px; height:400px;" align="center">
            <img height= "70" width="70" class="img-responsive" src="data:image;charset=utf8;base64,'. base64_encode($row ['image']) . '"><br />	
            	<h4 class="text-info">'.$row["product_name"].'</h4>
            	<h4 class="text-danger"> &#x20B5&nbsp'.$row["price"] .'</h4>
            	<input type="text" name="quantity" id="quantity' . $row["product_id"] .'" class="form-control"  placeholder="Quantity" />
            	<input type="hidden" name="hidden_name" id="name'.$row["product_id"].'" value="'.$row["product_name"].'" />
            	<input type="hidden" name="hidden_price" id="price'.$row["product_id"].'" value="'.$row["price"].'" />
            	<input type="button" name="add" id="'.$row["product_id"].'" style="margin-top:5px; display:none;" class="btn btn-primary form-control add_to_cart " value="Add to Cart"  ><label for="'.$row["product_id"].'"><span class="las la-cart-plus" style="  font-size: 1.5em; background-color: #89CFF0; color: black; border-radius: 30px;padding:4%; margin: 10px;
                ">Add To Cart</span></label>
            </div>
        </div>
		';
	}
}
	echo $output;
        }
        
        public function itemsz(){
            $query = "SELECT * FROM products";
            $stmt = $this->con->prepare($query);
            $stmt->execute();
            //echo '<tr>' ;
            $currency = "GH '&#8373'";
            echo '<div class="cards">';
            $i = 1;
            while($row = $stmt->fetch()){
                echo '<div class="card-single">';
									echo    '<img height= "100" width="100" src="data:image;charset=utf8;base64,'. base64_encode($row ['image']) . '" />' ;
                                    #echo '<form method="post">';
                                    echo '<div class="p_name">'. $row ["product_name"] .'</div> ';
									echo    '<div class="tag"> &#x20B5&nbsp'.$row ["price"] . '</div><br>';
                                    echo '<input type="hidden" name="product_name'. $row["product_id"] .'" value="'. $row["product_name"] .'" id="product_name" >';
                                    echo '<input type="hidden" name="product_id" value="'. $row["product_id"] .'" id="product_id"><br>';
                                    echo '<input type="hidden" name="price'. $row["product_id"] .'" value="'. $row["price"] .'" id="price"><br>';
                                    echo '<input class="p_name2" type="number" name="quantity'. $row["product_id"] .'" id="quantity" placeholder="Quantity">';
                                    echo '<button style="display: none;" type="button" id="'. $row["product_id"] .'" name="add'. $row["product_id"] .'" onclick="submitForm'. $row["product_id"] .'();"  ></button>';
                                    echo '<label for="add'. $row["product_id"] .'"><div class="show"><span class="las la-cart-plus"></span></div></label>';
                                    #echo '</form>';
                                    echo '</div> ';
                                    echo '<input type = "hidden" name="loop_value" value="'. $i++ .'">';
                                }   
            echo '</div>';
        
        }

        public function items2(){
            $query = "SELECT * FROM products";

$statement = $this->con->prepare($query);

if($statement->execute())
{
	$result = $statement->fetchAll();
	$output = '';
	foreach($result as $row)
	{
		$output .= '
		<div class="col-md-3" style="margin-top:12px;">  
            <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:2px; height:350px;" align="center">
            <img height= "100" width="100" class="img-responsive" src="data:image;charset=utf8;base64,'. base64_encode($row ['image']) . '"><br />	
            	<h4 class="text-info">'.$row["product_name"].'</h4>
            	<h4 class="text-danger"> &#x20B5&nbsp'.$row["price"] .'</h4>
            	<input type="text" name="quantity" id="quantity' . $row["product_id"] .'" class="form-control" value="1" />
            	<input type="hidden" name="hidden_name" id="name'.$row["product_id"].'" value="'.$row["product_name"].'" />
            	<input type="hidden" name="hidden_price" id="price'.$row["product_id"].'" value="'.$row["price"].'" />
            	<input type="button" name="add_to_cart" id="'.$row["product_id"].'" style="margin-top:5px;" class="btn btn-primary form-control add_to_cart" value="Add to Cart" />
            </div>
        </div>
		';
	}
	echo $output;
}


            
        
        }
        public function cart(){
            $total_price = 0;
            $total_item = 0;

            $output ='
            <div class="table-responsive" id="order_table">
            <table>
            <tr>
            <th>Product Name</th>
            <th>Quantity </th>
            <th>Price </th>
            <th>Total </th>
            <th>Action </th>
            </tr>
';
            if(!empty($_SESSION['shopping_cart'])){
                foreach($_SESSION['shopping_cart'] as $keys => $values){
                    $output .='
                    <tr>
                        <td>'.$values["product_name"].'</td>
                        <td>'.$values["quantity"].'</td>
                        <td>'.$values["product_price"].'</td>
                        <td>'.number_format($values["quantity"] * $values["product_price"],2).'</td>
                        <td><button name="delete"id="'.$values["product_id"].'">R</button></td>
                        <tr>
                    ';
                    $total_price = $total_price + ($values["product_quantity"] * $values["product_price"]);
                    $total_item = $total_item + 1;
                }
                $output .='
                    <tr>
                        <td>Total</td>
                        <td id="the_price">$'.number_format($total_price,2).'</td>
                    </tr>
                ';
            }else{
                $output .='
                <tr>
                    <td>Empty Cart</td>
                </tr>
                ';

            }
            $output .='
            </table>
            </div>
            ';
            $data = array(
                'cart_details' => $output,
                'total_price' => '$' . number_format($total_price,2),
                'total_item' => $total_item  
            );
            echo json_encode($data);
        }
        //
        public function history(){
            $query = "SELECT * FROM " . $this->table2 . " WHERE sess_id= :session_id  ";
            $stmt = $this->con->prepare($query);
            $stmt->bindParam(':session_id', $_SESSION['user_id']);
            $stmt->execute();
            //echo '<tr>' ;
            echo '</tr>';
            while($row = $stmt->fetch()){
									echo '<td>' .  $row ["sales_id"] . '</td>';
									echo '<td>' .  $row ["products_bought"] . '</td>';
									echo '<td>' .  $row ["quantity_bought"] . '</td>';
									echo '<td>' .  $row ["product_price"] . '</td>';
                                    echo '<td>' .  $row ["total"] . '</td>';
                                    echo '<td>' .  $row ["date_bought"] . '</td>';
                                    echo'<td><button id=' . $row["sales_id"] . ' class="ref_button">Refund</button></td>';
                                    echo '</tr>';
                                }   
                                        
        
        }
        public function all_cart(){
            if(isset($_POST["action"]))
{
	if($_POST["action"] == "add")
	{
		if(isset($_SESSION["shopping_cart"]))
		{
			$is_available = 0;
			foreach($_SESSION["shopping_cart"] as $keys => $values)
			{
				if($_SESSION["shopping_cart"][$keys]['product_id'] == $_POST["product_id"])
				{
					$is_available++;
					$_SESSION["shopping_cart"][$keys]['product_quantity'] = $_SESSION["shopping_cart"][$keys]['product_quantity'] + $_POST["product_quantity"];
				}
			}
			if($is_available == 0)
			{
                
				$item_array = array(
					'product_id'               =>     $_POST["product_id"],  
					'product_name'             =>     $_POST["product_name"],  
					'product_price'            =>     $_POST["product_price"],  
					'product_quantity'         =>     $_POST["product_quantity"]
				);
				$_SESSION["shopping_cart"][] = $item_array;
			}
		}
		else
		{
			$item_array = array(
				'product_id'               =>     $_POST["product_id"],  
				'product_name'             =>     $_POST["product_name"],  
				'product_price'            =>     $_POST["product_price"],  
				'product_quantity'         =>     $_POST["product_quantity"]
			);
			$_SESSION["shopping_cart"][] = $item_array;
            
		}
	}

	if($_POST["action"] == 'remove')
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["product_id"] == $_POST["product_id"])
			{
                $query = "DELETE FROM " . $this->table2 . " WHERE session_id= :session_id AND p_id= :product_id";
                $stmt = $this->con->prepare($query);
                $stmt->bindParam('session_id', $_SESSION['user_id']);
                $stmt->bindParam('product_id', $values["product_id"]);
                $stmt->execute();
				unset($_SESSION["shopping_cart"][$keys]);
                
			}
		}
        
	}
	if($_POST["action"] == 'empty')
	{
        $query = "DELETE FROM " . $this->table2 . " WHERE session_id= :session_id ";
        $stmt = $this->con->prepare($query);
        $stmt->bindParam('session_id', $_SESSION['user_id']);
        $stmt->execute();
		unset($_SESSION["shopping_cart"]);
	}
}


        }


        public function refund(){
        $query2 = "SELECT * FROM " . $this->table2 . " WHERE sess_id = :sess_id AND sales_id = :sales_id";
        $stmt2 = $this->con->prepare($query2);
        $stmt2->bindParam('sess_id', $this->session_id);
        $stmt2->bindParam('sales_id',$this->sales_id);
        $stmt2->execute();
        if(true){
        $row2 = $stmt2->fetch();
        $_SESSION['refund_total'] = $row2 ['total'];
        $query = "DELETE FROM " . $this->table2 . " WHERE sales_id= :sales_id ";
        $stmt = $this->con->prepare($query);
        $stmt->bindParam('sales_id',$this->sales_id);
        unset($_SESSION["shopping_cart"]);
        if($stmt->execute()){
            return true;
        }
        else{
            return false;
        }
        
        }else{
            return false;
        }
    }
        public function add(){
            $is_available = 0;
            foreach($_SESSION["shopping_cart"] as $keys => $values){
                if($_SESSION["shopping_cart"][$keys]['product_id'] == $_POST['product_id']){
                     $is_available++;
                     $_SESSION["shopping_cart"][$keys]['product_quantity'] = $_SESSION["shopping_cart"][$keys]['product_quantity'] +$_POST["product_quantity"];

            
                    }
        }
    }

        public function newadd(){
            $item_array = array(
                'product_id' => $_POST["product_id"],
                'product_name' => $_POST["product_name"],
                'product_price' => $_POST["product_price"],
                'product_quantity' => $_POST["quantity"]
            );
            $_SESSION["shopping_cart"][] = $item_array;
        }
        public function count(){
            $query = "SELECT * FROM " . $this->table2 . " WHERE sess_id = :id ";
            $stmt = $this->con->prepare($query);
            
            $stmt->bindParam(':id', $_SESSION['user_id']);
            $stmt->execute();
            $row = $stmt -> rowCount();
            
            return $row;
        
        }
        
        public function fetcharray(){
            $query = "SELECT * FROM " . $this->table1 . " WHERE requester_id = :id AND status = :status ";
            $stmt = $this->con->prepare($query);
            $this->status = "Pending";
            $stmt->bindParam(':id', $this->requester_id);
            $stmt->bindParam(':status', $this->status );
            $stmt->execute();
            $row = $stmt -> fetch(PDO::FETCH_BOTH);
            $details = array(
                "transaction_id" => $row['transaction_id'],
                "requester_id" => $row['requester_id'],
                "recipient_id" =>$row['recipient_id'],
                "amount" =>$row['amount'],
                "status" => $row['status'],
                "reference" => $row['reference'],
                "type" => $row['type'],
                "time_requested" => $row['time_requested']
            );
            return json_encode($details);
            
        
        }
        public function fetchassoc(){
            $query = "SELECT * FROM " . $this->table . " WHERE session_id = :session_id  limit 0,1";
            $stmt = $this->con->prepare($query);
            
            $stmt->bindParam(':session_id', $_SESSION['user_id']);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $details = array(
                "id" => $row['session_id'],
                "firstname" => $row['firstname'],
                "email" => $row['email']
            );
            return json_encode($details);
        
        }
        public function transfer(){
            $query = "INSERT INTO " . $this->table1 .  " SET  transaction_id= :transaction_id, requester_id= :requester_id, recipient_id= :recipient_id, amount= :amount, status= :status, reference= :reference, type= :type";
            $stmt = $this->con->prepare($query);
            $this->amount = htmlspecialchars(strip_tags($this->amount));
            $this->reference = htmlspecialchars(strip_tags($this->reference));
            $this->transaction_id = uniqid('TXD',true);
            $this->status = 'Pending';
            $this->requester_id = htmlspecialchars(strip_tags($this->requester_id));
            $this->recipient_id = htmlspecialchars(strip_tags($this->recipient_id));
            $this->type = 'External';

            $stmt->bindParam(':transaction_id', $this->transaction_id);
            $stmt->bindParam(':requester_id', $this->requester_id);
            $stmt->bindParam(':recipient_id', $this->recipient_id);
            $stmt->bindParam(':amount', $this->amount);
            $stmt->bindParam(':reference', $this->reference);
            $stmt->bindParam(':status', $this->status);
            $stmt->bindParam(':type', $this->type);
           
            if($stmt->execute()){
                $query2 = "UPDATE " . $this->table . " SET balance = :newbalance where bank_account_number = :request_id ";
                $stmt2 = $this->con->prepare($query2);
                $bal = intval($this->balance);
                $newb = intval($this->amount);
                $this->newbalance =  $bal-$newb; 
                $stmt2->bindParam(':request_id', $this->requester_id);
                $stmt2->bindParam(':newbalance', $this->newbalance);
                $stmt2->execute();

            return true;
            }
            else{
                printf("Error: %s\n", $stmt->error);
            return false;
            }
        }
        public function deposit(){
            $query = "INSERT INTO " . $this->table1 .  " SET  transaction_id= :transaction_id, requester_id= :requester_id, recipient_id= :recipient_id, amount= :amount, status= :status, reference= :reference, type= :type";
            $stmt = $this->con->prepare($query);
            $this->amount = htmlspecialchars(strip_tags($this->amount));
            $this->reference = htmlspecialchars(strip_tags($this->reference));
            $this->transaction_id = uniqid('TXD',true);
            $this->status = 'Complete';
            $this->requester_id = htmlspecialchars(strip_tags($this->requester_id));
            $this->recipient_id = htmlspecialchars(strip_tags($this->recipient_id));
            $this->type = "Deposit";


            $stmt->bindParam(':transaction_id', $this->transaction_id);
            $stmt->bindParam(':requester_id', $this->requester_id);
            $stmt->bindParam(':recipient_id', $this->recipient_id);
            $stmt->bindParam(':amount', $this->amount);
            $stmt->bindParam(':reference', $this->reference);
            $stmt->bindParam(':status', $this->status);
            $stmt->bindParam(':type', $this->type);

            if($stmt->execute()){
                $query2 = "UPDATE " . $this->table . " SET balance = :newbalance where bank_account_number = :request_id ";
                $stmt2 = $this->con->prepare($query2);
                $bal = intval($this->balance);
                $newb = intval($this->amount);
                $this->newbalance =  $newb+$bal; 
                $stmt2->bindParam(':request_id', $this->requester_id);
                $stmt2->bindParam(':newbalance', $this->newbalance);
                $stmt2->execute();
                
            return true;
            }
            else{
                printf("Error: %s\n", $stmt->error);
            return false;
            }
        }
        public function transfer2(){
            $query = "INSERT INTO " . $this->table1 .  " SET  transaction_id= :transaction_id, requester_id= :requester_id, recipient_id= :recipient_id, amount= :amount, status= :status, reference= :reference, type= :type";
            $stmt = $this->con->prepare($query);
            $this->amount = htmlspecialchars(strip_tags($this->amount));
            $this->reference = htmlspecialchars(strip_tags($this->reference));
            $this->transaction_id = uniqid('TXD',true);
            $this->status = 'Pending';
            $this->requester_id = htmlspecialchars(strip_tags($this->requester_id));
            $this->recipient_id = htmlspecialchars(strip_tags($this->recipient_id));
            $this->type = "Internal";


            $stmt->bindParam(':transaction_id', $this->transaction_id);
            $stmt->bindParam(':requester_id', $this->requester_id);
            $stmt->bindParam(':recipient_id', $this->recipient_id);
            $stmt->bindParam(':amount', $this->amount);
            $stmt->bindParam(':reference', $this->reference);
            $stmt->bindParam(':status', $this->status);
            $stmt->bindParam(':type', $this->type);

            if($stmt->execute()){
                $query2 = "UPDATE " . $this->table . " SET balance = :newbalance where bank_account_number = :request_id ";
                $stmt2 = $this->con->prepare($query2);
                $bal = intval($this->balance);
                $newb = intval($this->amount);
                $this->newbalance =  $bal-$newb; 
                $stmt2->bindParam(':request_id', $this->requester_id);
                $stmt2->bindParam(':newbalance', $this->newbalance);
                $stmt2->execute();
                
            return true;
            }
            else{
                printf("Error: %s\n", $stmt->error);
            return false;
            }
        }
        public function alreadyadded(){
            $query = "SELECT * FROM " . $this->table2 . " WHERE session_id= :session_id AND product_id= :product_id ";
            $stmt = $this->con->prepare($query);
            $stmt->bindParam(':session_id', $this->session_id);
            $stmt->bindParam(':product_id', $this->product_id);
            $stmt->execute();
            $result = $stmt->fetchAll();
	$records = count($result);
        if($records >= 1){
            $t = "false";
            return $t;
        }else if($records == 0){
            $t = "true";
            return $t;
        }
        }
        public function addtosales(){
            $query = "INSERT INTO " . $this->table2 .  " SET  session_id= :session_id, product_id= :product_id, product_name= :product_name, quantity_bought= :quantity, price= :price, total= :total";
            $stmt = $this->con->prepare($query);
            $newquantity = intval($this->quantity);
            $newprice = intval($this->product_price);
            $stmt->bindParam(':session_id',$this->session_id);
            $stmt->bindParam(':product_id', $this->product_id);
            $stmt->bindParam(':product_name', $this->product_name);
            $stmt->bindParam(':quantity', $newquantity);
            $stmt->bindParam(':price', $newprice);
            $total = $newquantity * $newprice; 
            $stmt->bindParam(':total', $total);
            if($stmt->execute()){
                return true;
            }
            else{
                return false;
            }
        }
    
}
