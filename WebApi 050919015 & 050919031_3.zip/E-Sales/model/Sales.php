<?php
class Sales{
    private $con;
    private $table = "users";
    //setting attributes
    public $user_id;
    public $firstname;
    public $phone_number;
    public $email;
    public $password;

    public function __construct($db){
        $this->con=$db;
    }
    public function checkemail(){
        $query = "SELECT * FROM " . $this->table . " WHERE email = :email  limit 0,1";
        $stmt = $this->con->prepare($query);
        $stmt->bindParam(':email', $this->email);
        $stmt->execute();
    $result = $stmt->fetchAll();
	$records = count($result);
        if($records >= 1){
            $t = "false";
            return $t;
        }else if($records == 0){
            $t = "true";
            return $t;
        }

    }
    //creating users
    public function createuser(){
    $query = "INSERT INTO " . $this->table . " SET user_id= :user_id, firstname= :firstname, phone_number= :phone_number, email= :email, password= :password";
    $stmt = $this->con->prepare($query);
    //clean data
    $this->firstname = htmlspecialchars(strip_tags($this->firstname));
    $this->phone_number = htmlspecialchars(strip_tags($this->phone_number));
    $this->email = htmlspecialchars(strip_tags($this->email));
    $this->password = htmlspecialchars(strip_tags($this->password));       
    $this->user_id = uniqid('USR_ID',true);
        //bind
    $stmt->bindParam(':user_id', $this->user_id);
    $stmt->bindParam(':firstname', $this->firstname);
    $stmt->bindParam(':phone_number', $this->phone_number);
    $stmt->bindParam(':email', $this->email);
    $stmt->bindParam(':password', $this->password);

    if($stmt->execute()){
        return true;
    }
    else{
        printf("Error: %s\n", $stmt->error);
        return false;
    }
}
public function login($email,$password){
    $query = "SELECT COUNT(*) FROM " . $this->table . " WHERE email = :email AND password = :password limit 0,1";
    $stmt = $this->con->prepare($query);
        //bind id to placeholder
    $stmt->bindParam(':email', $this->email);
    $stmt->bindParam(':password', $this->password);
    $stmt->execute();
    //if($stmt -> fetchColumn() > 0){
    //$row = $stmt->fetch(PDO::FETCH_ASSOC);
        //$row['email'] === $this->email && $row['password'] === $this->password
    if($stmt -> fetchColumn() == 1){
        $query2 = "UPDATE " . $this->table . " SET session_id = :session_id where email = :email ";
        $stmt2 = $this->con->prepare($query2);
        $stmt2->bindParam(':session_id',uniqid("SES",true));
        $stmt2->bindParam(':email', $this->email); 
        $stmt2->execute();
        $t = "true";
        return $t;
    }else if($stmt -> fetchColumn() < 1){
        $t = "false";
        return $t;
    }
}
public function fetchassoc(){
    $query = "SELECT * FROM " . $this->table . " WHERE email = :email  limit 0,1";
    $stmt = $this->con->prepare($query);
    $stmt->bindParam(':email', $this->email);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $id =  $row['session_id'];
    return $id;

}


}