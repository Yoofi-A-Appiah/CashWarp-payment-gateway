<?php


class CheckOut{
    private $con;
    
    private $table2 = "sales";
    //setting attributes
    public $api_key ;
    public $session_id;
    public $total_price;
    public $product_name;
    public $product_price;
    public $product_quantity;
    public $product_id;

    

    public function __construct($db){
        $this->con=$db;
    }

    function check_login($id){

        if (isset($_SESSION['user_id'])){
        
            $id = $_SESSION['user_id'];
            $query = "SELECT COUNT(*) from users where sess= :session_id limit 1";
            $stmt = $this->con->prepare($query);
            $stmt->bindParam(':session_id', $this->session_id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if($row){
                $user_data = $row;
                return $user_data;
            }else{
                return null;
            }
        
        }
        else{
        //redirect to login
        header("Location: index.php");
        die;}
        }
        
        public function purchased(){
            $query = "SELECT * FROM " . $this->table2 . " WHERE session_id = :session_id" ;
            $stmt = $this->con->prepare($query);
            $stmt->bindParam(':session_id', $_SESSION['user_id']);
            $stmt->execute();
            #$row = $stmt -> fetch(PDO::FETCH_BOTH);
            #$row = $stmt->fetchAll();
            $i=1;
	        while($row = $stmt->fetch()){
                
                echo '<div class="form-row">';
                echo '<div >' .$row["products_bought"].'</div>';
                echo '<div>&#x20B5&nbsp' .$row["product_price"] .'</div>';
                echo '<div >' .$row["quantity_bought"] .'</div>';
                echo '</div>';
                $i++;
            }   
    }
    public function total(){
    $query = "SELECT * FROM " . $this->table2 . " WHERE sess_id = :session_id" ;
    $stmt = $this->con->prepare($query);
    $stmt->bindParam(':session_id', $_SESSION['user_id']);
    $stmt->execute();
    #$row = $stmt -> fetch(PDO::FETCH_BOTH);
    #$row = $stmt->fetchAll();
    
    $total_price = 0;
    while($row = $stmt->fetch()){
        $total_price = $total_price + ($row["quantity_bought"] * $row["product_price"]);
        
    }
    $this->total_p = $total_price;
    return $total_price;
}
    public function c_out(){
        $url= 'http://localhost/LifeLineBank/views/middle.php'; 
        $postVars = array(
            'foo' => 'ee',
            'bar' => 'lee'
        );
        //Transform our POST array into a URL-encoded query string.
        $postStr = http_build_query($postVars);
        //Create an $options array that can be passed into stream_context_create.
        $options = array(
            'http' =>
                array(
                    'method'  => 'POST', //We are using the POST HTTP method.
                    'header'  => 'Content-type: application/x-www-form-urlencoded',
                    'content' => $postStr //Our URL-encoded query string.
                )
        );
        //Pass our $options array into stream_context_create.
        //This will return a stream context resource.
        $streamContext  = stream_context_create($options);
        //Use PHP's file_get_contents function to carry out the request.
        //We pass the $streamContext variable in as a third parameter.
        $result = file_get_contents($url, false, $streamContext);
        //If $result is FALSE, then the request has failed.
        if($result === false){
            //If the request failed, throw an Exception containing
            //the error.
            $error = error_get_last();
            throw new Exception('POST request failed: ' . $error['message']);
        }
        //If everything went OK, return the response.
        //return $result;
}
public function c_out2(){
    /*$url = 'http://localhost/LifeLineBank/views/middle.php';
 
$curl = curl_init();
$headers = [];
$token = $this->api_key;
$headers[] = "Authorization: Bearer ".$token;
 $amount = $this->total();
 //$j = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2NTE2Njc0NjcsImV4cCI6MTY1MTY3MTA2NywiaXNzIjoiaHR0cDovL2xvY2FsaG9zdC9MaWZlTGluZUJhbmsvQmFuay5waHAifQ.0tdkE9pWt2UX7mOyf1yLWZFYZ4qrP3XHfbClpnfCvYI';

$fields = array(
    
    'amount' => $amount
);
 
$fieldsa = http_build_query($fields);
 
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, TRUE);
curl_setopt($curl, CURLOPT_POSTFIELDS, $fieldsa);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
 
 
 curl_exec($curl);
 
curl_close($curl);
*/
$token = $this->api_key;
$amount = $this->total();
$_SESSION['amount'] = $amount;
$_SESSION['token'] = $token;
$result = 'true';
//header("Authorization: Bearer ".$token);
//setcookie('token',$token);

//header('Content-Type: ');
//header("Location: http://localhost/LifeLineBank/views/middle.php");
//header("Set-Cookie: amount");
return $result;
}
public function refund(){
    $token = $this->api_key;
$amount = $this->total();
$_SESSION['product_id'] = $amount;
$_SESSION['token'] = $token;
$result = 'true';
return $result;

}
public function intoDb(){
    foreach($_SESSION["shopping_cart"] as $keys => $values)
    {
        //var_dump($values['product_quantity']);
        $this->product_id = $values['product_id'];
        $this->product_name = $values['product_name'];
        $this->product_price = $values['product_price'];
        $this->product_quantity = $values['product_quantity'];
        $quant = $this->product_quantity;
                $single_price = $this->product_price;
                $int_quant = intval($quant);
                $int_single_price = intval($single_price);
                $insert_total = $int_quant * $int_single_price;
                //$insert_total = 30;
                $query = "INSERT INTO " . $this->table2 . " SET sess_id= :session_id, p_id= :product_id, products_bought= :products_bought, quantity_bought= :quantity_bought, product_price= :product_price, total= :total";
            $stmt = $this->con->prepare($query);
            $stmt->bindParam('session_id', $_SESSION['user_id']);
            $stmt->bindParam('product_id', $this->product_id);
            $stmt->bindParam('products_bought', $this->product_name);
            $stmt->bindParam('quantity_bought', $this->product_quantity);
            $stmt->bindParam('product_price', $this->product_price);
            $stmt->bindParam(':total', $insert_total);
            $stmt->execute();  
    }
    
    $re = "true";
    return $re;
                
}

}
