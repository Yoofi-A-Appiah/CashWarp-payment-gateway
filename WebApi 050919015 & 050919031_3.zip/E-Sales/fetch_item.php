<?php

//fetch_item.php

include('config/dbconnect.php');
include('model/Interactions.php');

$database = new Database;
$db = $database->connect();
$interact = new Interaction($db);
header('Access-Control-Allow-Origin: *');

$interact->items();
?>