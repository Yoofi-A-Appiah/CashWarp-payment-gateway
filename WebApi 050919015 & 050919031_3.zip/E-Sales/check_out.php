<?php
session_start();
include ("config/dbconnect.php");
include ("model/CheckOut.php");
include ("model/Interactions.php");
$database = new Database;
$db = $database->connect();
$checkout = new CheckOut($db);
$interact = new Interaction($db);
$id = $_SESSION['user_id'];
$user_data = $interact->check_login($id);
$all = $checkout->total();
if(empty($_SESSION['shopping_cart'])){
	header("Location: selling.php?error=You have not added any item to cart. You can't proceed");
}
else{	
//$api_k =  $_SESSION['apk'];

//var_dump($_SESSION);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Check Out</title>
		<link rel="stylesheet" href="checkoutstyle.css" />
		<script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<body>
			

<div id="backtosales" onclick="window.history.back()">If redrect didint work you can manually go back here</div>
<div class="center">
				<p class="spinner" id="spinner"><img src="/assets/img/Hourglass.gif" alt="Computer man"></p>

				</div>
  

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

	</body>
</html>
<script>
$(document).ready(function(){ 
			
			var api_key = '7a325b-78b98d-537093-2682fc-d2088d';
			
			if(api_key != ''){
				var formData = {api_key: api_key};
                $.ajax({url: 'includes/c_out.php', type:'POST',data: formData, dataType: "text", success: function(response){
					console.log(response);
					switch (response){
    					case 'true':
							console.log('It is true')
							<?php //header("Location: http://localhost/LifeLineBank/views/middle.php" )?>
							
			
							window.open("http://localhost/LifeLineBank/views/middle.php");
							
    					break;
    					case 'false':
							$('.replaced').replaceWith("<div> ERROR</div>");
    					break;
					
    					
					}
				}
				
				
			});
			 
	}else{
			$('.replaced').append("<div>All fields are required</div>");

		}
		document.getElementById("backtosales").click();

	})
</script>
<?php }?>