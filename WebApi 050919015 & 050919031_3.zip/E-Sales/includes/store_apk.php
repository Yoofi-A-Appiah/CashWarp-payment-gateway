<?php
session_start();
if(isset($_POST['ap'])){

$api_key = $_POST['ap'];
$_SESSION['apk'] = $api_key;
$response = "true";
}
else {
    $response = "false";
}
echo $response;
//echo var_dump($_POST);
?>