<?php
session_start();

include ("../model/Interactions.php");
include ("../config/dbconnect.php");

$database = new Database;
$db = $database->connect();
$interact = new Interaction($db);
header('Access-Control-Allow-Origin: *');
if(isset($_POST['add'])){
$product_name = $_POST['product_name'];
$product_price = $_POST['int_price'];
$quantity =$_POST['actual'];
$product_id = $_POST['product_id'];
$session_id = $_SESSION['user_id'];

$interact->product_id = $product_id;
$interact->product_name = $product_name;
$interact->product_price = $product_price;
$interact->quantity = $quantity;
$interact->session_id = $session_id;

$already_added = $interact->alreadyadded();
#if($already_added === "true"){


$done = $interact->addtosales();
switch ($done){
    case true:
    $response = "true";
    
    break;
    case false:
    $response = "false";
   
    break;
    default:
    $response = "false";
    
}
#}
#else{
#   $response = "already";
    
#}


echo $response;
}
//echo $response;
