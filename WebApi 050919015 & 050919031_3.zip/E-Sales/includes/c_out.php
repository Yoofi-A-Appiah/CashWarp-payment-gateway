<?php
session_start();

include ("../model/Interactions.php");
include ("../config/dbconnect.php");
include ("../model/CheckOut.php");

$database = new Database;
$db = $database->connect();
$checkout = new CheckOut($db);
$interact = new Interaction($db);
header('Access-Control-Allow-Origin: *');

if(isset($_POST['api_key'])){
    $into = $checkout->intoDb();
    if($into == "true"){
    $checkout->api_key = $_POST['api_key'];
            $check_out = $checkout->c_out2();
            if($check_out == 'true'){
                $response = 'true';
            }
        }else{
            echo "Not working";
        }
}else{
    $response = 'false';
}
echo $response;
