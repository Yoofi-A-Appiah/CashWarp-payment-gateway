<?php
session_start();

include ("../model/Interactions.php");
include ("../config/dbconnect.php");

$database = new Database;
$db = $database->connect();
$interact = new Interaction($db);
header('Access-Control-Allow-Origin: *');
if(isset($_POST['id'])){
$sales_id = $_POST['id'];
$interact->sales_id = $sales_id;
$done = $interact->refund();
switch ($done){
    case true:
        if(isset($_SESSION['shopping_cart'])) {
            unset($_SESSION['shopping_cart']);
        }
    $response = "true";
    
    break;
    case false:
    $response = "false";
   
    break;
    default:
    $response = "false";
    
}


echo $response;
}
