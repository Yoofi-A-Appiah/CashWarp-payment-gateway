<?php
session_start();

include ("../model/Interactions.php");
include ("../config/dbconnect.php");
include ("../model/CheckOut.php");

$database = new Database;
$db = $database->connect();
$checkout = new CheckOut($db);
$interact = new Interaction($db);
header('Access-Control-Allow-Origin: *');

if(isset($_POST['api_key']) && isset($_POST['id'])){
    $checkout->api_key = $_POST['api_key'];
            $check_out = $checkout->refund();
                $sales_id = $_POST['id'];
                $interact->session_id = $_SESSION['user_id'];
                $interact->sales_id = $sales_id;
                 $interact->refund();
                        if(isset($_SESSION['shopping_cart'])) {
                            unset($_SESSION['shopping_cart']);
                        }
                        $response = 'true';
}else{
    $response = 'false';
}
echo $response;
