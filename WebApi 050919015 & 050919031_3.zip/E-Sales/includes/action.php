<?php
session_start();

include ("../model/Interactions.php");
include ("../config/dbconnect.php");
$database = new Database;
$db = $database->connect();
$interact = new Interaction($db);
header('Access-Control-Allow-Origin: *');

if(isset($_POST['action'])){
    if($_POST["action"] === "add"){
        if(isset($_SESSION["shopping_cart"])){
            $interact->add();
        if($interact->$is_available == 0){
            $interact->newadd();
        }
        }else{
             $interact->newadd();

        }

    }
}