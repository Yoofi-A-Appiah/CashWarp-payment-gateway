    <div class="navbar navbar-fixed-top navbar-inverse" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a href="views/logout.php" class="navbar-brand"><img src="assets/img/laptop2.png" alt="" class="navbar-brand"></a>

        </div>
        <div class="collapse navbar-collapse">
          <ul class="nav navbar-nav">

            <li><a class="nav-link scrollto " href="views/logout.php">Logout</a></li>
            <li><a class="nav-link scrollto " href="views/transaction_history.php">View Transaction History</a></li>

            <li>
                <a id="cart-popover" class="btn" data-placement="bottom" title="Shopping Cart">
                  <span class="glyphicon glyphicon-shopping-cart"></span>
                  <span class="badge active"></span>
                  <span class="total_price">&#8373; 0.00</span>
                </a>
              </li>
           
          </ul>
        </div><!-- /.nav-collapse -->
      </div><!-- /.container -->
    </div><!-- /.navbar -->



