<?php
session_start();
include ("../config/dbconnect.php");
include ("../model/Interactions.php");
$database = new Database;
$db = $database->connect();
$interact = new Interaction($db);
$id = $_SESSION['user_id'];
$user_data = $interact->check_login($id);

#$all = $interact->fetchassoc();
#$obj = json_decode($all);
#$interact->requester_id = $obj->bank_account_number;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>On Sale</title>
    <meta content="" name="description">
  <meta content="" name="keywords">
  <link href="../assets/img/laptop.png" rel="icon">

        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
        <link href="../assets/css/main.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
        <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
</head>
<body>
    
    <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

     <!-- <h1 class="logo"><a href="index.html">E-Sales</a></h1>
       Uncomment below if you prefer to use an image logo -->
      <a href="index.html" class="logo"><img src="../assets/img/laptop2.png" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto " href="logout.php">Home</a></li>
            <li><a class="nav-link scrollto " href="logout.php">Logout</a></li>
            <li><a class="nav-link scrollto active" href="#">View Cart<div class="cart"><span class="las la-shopping-cart" id="shop">0</span></div></a></li>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>
   
    
  <section  class="d-flex align-items-center">   
  
<div class="replace"></div>
<form method="post" id="form">
<?php $interact->itemsz(); ?>
  

</form>
        
        
        <div class="container" data-aos="fade-up" data-aos-delay="100">
    </div>
    
  </section> 
  
  <div id="popover_content_wrapper" >
    <span id="cart_details"></span>
    <div allign="right">
    <span class="total_price">$ 0.00</span><br>
     <a href="#" class="btn btn-primary" id="check_out_cart">
     
     <span class="glyphicon glyphicon-shopping-cart"></span> Check out
     </a>
     <a href="#" class="btn btn-default" id="clear_cart">
     <span class="glyphicon glyphicon-trash"></span> Clear
     </a>
    </div>
   </div>
   



</body>
<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3>E-Sales</h3>
              <p>
                1D46 Accra-Madina<br>
                ACC 535022, GHA<br><br>
                <strong>Phone:</strong> +233 54 5510 836<br>
                <strong>Email:</strong> esales@gmail.com<br>
                
              </p>
            
              </div>
            </div>
          </div>

         
      <div class="credits">
        </div>
    </div>
  </footer>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>

</html>
<script>
    $(document).ready(function(){
            load_products();
            load_cart_data();
        function load_products(){
            $.ajax({
                url:"../includes/fetchproducts.php",
                method: "POST",
                success:function(data){
                    $('#form').html(data);
                }
            });
        }
        function load_cart_data(){
            $.ajax({
                url:"../includes/fetchcart.php",
                method: "POST",
                dataType: "json",
                success:function(data){
                    $('#cart_details').html(data.cart_details);
                    $('#total_price').html(data.totalprice);
                    $('#shop').html(data.totalitem);

                }
            });
        }
        $(document).on('click', '#add', function(){
            var product_id = $(this).attr("id");
            var product_name = $('#name'+product_id+'').val();
            var product_quantity = $('#quantity'+product_id).val();
            var q = parseInt(product_quantity);
            var product_price = $('#price'+product_id+'').val();
            var action = "add";
            console.log(product_quantity);
            if(q > 0){
                $.ajax({
                    url: "../includes/action.php",
                    method: "post",
                    data:{product_id:product_id,product_name:product_name,product_quantity:product_quantity,product_price:product_price,action:action},
                    success:function(data){
                        load_cart_data();
                        alert ("added to cart");
                    }
                });
            }else{
                alert("Please enter number of items");
            }

        })
    });
   
    function submitForm1(){
            var product_id = $(this).attr("id");

			let quantity = $('input[name=quantity'+product_id+']').val();
			let actual = parseInt(quantity);
			let product_name = $('input[name=product_name'+product_id+']').val();
			let price = $('input[name=price'+product_id+']').val();
            let int_price = parseInt(price);
            console.log(product_id);
			if( quantity !=''){
				
				let formData = {product_id: product_id, actual: actual, product_name: product_name, int_price: int_price};
                $.ajax({url: "../includes/addingtocart.php", type:'POST',data: formData, dataType: "text", success: function(response){
					
					console.log(response);
					switch (response){
    					case "true":
							
                            let current = document.getElementById('shop').innerHTML;
                            let cnumber = parseInt(current);
                            document.getElementById('shop').innerHTML = cnumber +1;
							 
    					break;
    					case "false":
							$('.replace').replaceWith("<div> Already added</div>");
    					break;
					}
                 
				
				}
			});
			 
		}else{
			$('.replaced').append("<div>Select quantity</div>");

		}
	}
</script>