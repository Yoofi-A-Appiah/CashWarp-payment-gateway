<?php
session_start();

include ("../model/Sales.php");
include ("../config/dbconnect.php");

$database = new Database;
$db = $database->connect();

$bankaccountErr = $emailErr = $passwordErr = $o_error = ""; 
$bank_account_number = $email = $password = "";
if(isset($_POST['submit'])){
      if (empty($_POST["email"])) {
        $emailErr = "Email is required";
      } else {
        $email = $_POST["email"];
      }
      if (empty($_POST["password"])) {
        $passwordErr = "password is required";
      } else {
        $password = $_POST["password"];
      }


if(!empty($email) && !empty($password)){

$sales = new Sales($db);
$encrypted_password = md5($password);



$sales->email = $email;
$sales->password = $encrypted_password;


$b = $sales->login($email,$password);
switch ($b){
    case "true";
    $all = $sales->fetchassoc();
    $_SESSION['user_id'] = $all;
    header('Location: admin.php');
    exit();
    break;
    case "false";
    
    $o_error = "The email and password combination is incorrect";
    
    break;
    default:
    $o_error = "The email password combination is incorrect";
    }
  }
}
?>
<html>
    <head>
        <title>
            ADMIN Login - ESales
        </title>
        <meta content="" name="description">
  <meta content="" name="keywords">
  <link href="../assets/img/laptop.png" rel="icon">

        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
        <link href="../assets/css/style.css" rel="stylesheet">
        <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
        <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
        </head>
        <body>
          <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="index.html">E-Sales</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <a href="index.html" class="logo"><img src="../assets/img/laptop.png" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto " href="../index.html">Home</a></li>
          <li><a class="nav-link scrollto" href="../index.html#about">About</a></li>
          <li><a class="nav-link scrollto" href="../index.html#categories">Categories</a></li>
          <li><a class="nav-link scrollto" href="../index.html#footer">Contact</a></li>
          <li><a class="nav-link scrollto active" href="login.php">Login</a></li>
          <li><a class="nav-link scrollto " href="signup.php">SignUp</a></li>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>
  
  <section id="hero" class="d-flex align-items-center">   

    <div class="container " data-aos="fade-up" data-aos-delay="300">
   
    <div class="form">
  <h2>ADMIN Log In</h2>
            
            

                <form method="post">
                
                <span id="repeat_error" style="color: red;"><?php echo $o_error; ?></span>
                   
                    <div class="input">
                    <span class="error"> <?php echo $emailErr;?></span><br>
                    <input class="in" type="email" name="email" placeholder="Enter email">
                    </div>
                    <div class="input">
                    <span class="error"> <?php echo $passwordErr;?></span> <br>
                    <input class="in" type="password" name="password" id="firstpassword" onkeyup="check()" placeholder="Enter Password">
                   
                    <div class="binput">
                    <input class="but" type="submit" name="submit" value="Log In" onclick="value();">
                    </div>
                </form>
            </div>  
    </div>
  </section>
  
  
            <br>
           
<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3>E-Sales</h3>
              <p>
                1D46 Accra-Madina<br>
                ACC 535022, GHA<br><br>
                <strong>Phone:</strong> +233 54 5510 836<br>
                <strong>Email:</strong> esales@gmail.com<br>
              </p>
            
              </div>
            </div>
          </div>

         
      <div class="credits">
        </div>
    </div>
  </footer>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>

        </body>
    
</html>


<script>
   
var show = function(){
    
    if(document.getElementById('firstpassword').type ==="password"){
      document.getElementById('firstpassword').type ="text";
      document.getElementById('show').className = "las la-eye-slash";

   }else if(document.getElementById('firstpassword').type ==="text"){
     document.getElementById('firstpassword').type ="password";
     document.getElementById('show').className = "las la-eye";

   }
  }
  


  
</script>

        </body>
    
</html>


<script>
  var show = function(){
    
    if(document.getElementById('firstpassword').type ==="password"){
      document.getElementById('firstpassword').type ="text";
      document.getElementById('show').className = "las la-eye-slash";

   }else if(document.getElementById('firstpassword').type ==="text"){
     document.getElementById('firstpassword').type ="password";
     document.getElementById('show').className = "las la-eye";

   }
  }
var check = function() {
  if (document.getElementById('secondpassword').value ==
    document.getElementById('firstpassword').value) {
    document.getElementById('repeat_error').style.color = 'green' ;
    document.getElementById('repeat_error').innerHTML = 'Passwords are matching';
    
  } else {
    document.getElementById('repeat_error').style.color = 'red';
    document.getElementById('repeat_error').innerHTML = 'Passwords are not matching';
  }
}
  
</script>