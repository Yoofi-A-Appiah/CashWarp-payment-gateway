<?php
session_start();
include ("../config/dbconnect.php");
include ("../model/Interactions.php");
$database = new Database;
$db = $database->connect();
$interact = new Interaction($db);
$id = $_SESSION['user_id'];
$user_data = $interact->check_login($id);
$interact->requester_id = $_SESSION['user_id'];
$all = $interact->fetchassoc();
$obj = json_decode($all);

?>
<html>
    <head>
   <!-- <link rel="shortcut icon" type="image" href="../images/.png">-->
        <title>Transfer Life Line Bank </title>
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
        <link rel="stylesheet" type="text/css" href="../assets/css/main.css">
        <link rel="stylesheet" type="text/css" href="../assets/css/history.css">
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="js/jquery.min.js"></script>
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<script src="js/bootstrap.min.js"></script>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">

<!-- Custom styles for this template -->
<link href="offcanvas.css" rel="stylesheet">
    </head>
    <body>
    <div class="navbar navbar-fixed-top navbar-inverse" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a href="logout.php" class="navbar-brand"><img src="assets/img/laptop2.png" alt="" class="navbar-brand"></a>

        </div>
        <div class="collapse navbar-collapse">
          <ul class="nav navbar-nav">

            <li><a class="nav-link scrollto " href="logout.php">Logout</a></li>
            <li><a class="nav-link scrollto " href="#">View Transaction History</a></li>
            <li><a class="nav-link scrollto " href="../selling.php">Back to Shop</a></li>

           
          </ul>
        </div><!-- /.nav-collapse -->
      </div><!-- /.container -->
    </div><!-- /.navbar -->







    <div class="main-content">
	<header>
	
<h2 id="account">Transaction History</h2>
<div id="account">Account Name: <?php echo $obj->email;?></div>			<div class="user-wrapper">
				
				<p id="greeting"></p>
				<div class="user-wrapper">Hello 
			 <?php echo $obj->firstname; ?>
				
			
				 
			</div>
			</div>
            
			
	</header>
    </div>
	<br>
	<main>
    <?php if( $interact->count() >= 1 )
        { ?>

    <div class="recent-grid">
			<div class="projects">
				<div class="card">
					<div class="card-header">
						<h2><?php echo $obj->firstname; ?>'s Transaction History</h2>
            
					</div>
					<div class="card-body">

					<div class="table-responsive">
									<table width="100%">
							<thead>
								<tr>
									<td>Transaction ID</td>
									<td>Products Bought</td>
									<td>Quantity Bought</td>
									<td>Product Price</td>
									<td>Total</td>
                                    <td>Date Bought</td>
                                    <td>Action </td>

								</tr>
							</thead>
							<tbody>
																
								<?php echo $interact->history(); }else{?><div class="nothing"><?php echo "No Purchase History";?></div><?php }?>
								
							</tbody>
						</table>
					</div>
					</div>
				</div>
			</div>
		</div>
	</main>
	
    </body>
    <script type="text/javascript">
        
		
		var today = new Date();
		let hour = today.getHours();
		
		let paragraph = document.getElementById("greeting");
		
		if(hour <=11 ){
			greeting="Good Morning";
		}
		if (hour <=18){
			greeting="Good Afternoon";
		}
		else if (hour > 18){
			greeting="Good Evening";
		}
		else{greeting = "Hello";}

		paragraph.innerHTML = greeting;
	</script>
    <script>
        //function make_refund(){
    
    
        //if (confirm("Are you sure you want to make a refund?"))
        //{
            //$(this).parent().parent().attr('id')
            $('.ref_button').click(function()
    {
            var id = this.id;
            //var data = 'id=' + id ;
            var parent = this.parent;
            var api_key = '7a325b-78b98d-537093-2682fc-d2088d';
            var formData = {id:id,api_key:api_key};
            console.log(parent);
            $.ajax(
            {
                   type: "POST",
                   url: "../includes/r_out.php",
                   data: formData,
                   success: function(response)
                   {
                            switch(response){
                              case "true":
                                alert("Refund request made for sale "+ id +" has been made");
                                window.open("http://localhost/LifeLineBank/views/middle_refund.php");

                                break;
                              case "false":
                                alert("Refund request made for sale "+ id +" was not possible");

                                break;
                            }
                   }
    //                complete:function(){

    //                 $.ajax({
    //                     type: "POST",
    //                     url: "../includes/r_out.php",
    //                     data: {api_key: api_key},
    //                     success: function(response){
    //                         switch (response){
    // 					case 'true':
		// 					console.log('It is true')
		// 					<?php //header("Location: http://localhost/LifeLineBank/views/middle.php" )?>
							
		// 					window.location.replace("http://localhost/LifeLineBank/views/middle_refund.php");
							
    // 					break;
    // 					case 'false':
		// 					$('.replaced').replaceWith("<div> ERROR</div>");
    // 					break;
					
    					
		// 			}
    //        },
    //    });
    // }
                   },
             );
        }
       )
       //}
        

    </script>
</html>